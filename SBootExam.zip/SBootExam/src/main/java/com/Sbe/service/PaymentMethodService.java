package com.Sbe.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Sbe.beans.PaymentMethod;
import com.Sbe.repository.PaymentMethodRepository;
@Service
public class PaymentMethodService {

		@Autowired
		PaymentMethodRepository paymentRepo;
		@Autowired
		ReturnLinksService retLinkService;
		
		public List<PaymentMethod> findAll()
		{
			Iterable data=paymentRepo.findAll();
			Iterator dataloop=data.iterator();
			List<PaymentMethod> newData=new ArrayList<PaymentMethod>();
			while(dataloop.hasNext())
			{
				newData.add((PaymentMethod)dataloop.next());
			}
			return newData;
		}
		public PaymentMethod findById(String id)
		{
			Optional<PaymentMethod> opt=Optional.empty();
			PaymentMethod tr=null;
			if(opt.isPresent())
				tr=opt.get();
			return tr;
		}
		public PaymentMethod save(PaymentMethod payment)
		{
			return paymentRepo.save(payment);
		}
		
		
	}



