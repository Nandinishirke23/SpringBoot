package com.Sbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBootExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SBootExamApplication.class, args);
	}

}
