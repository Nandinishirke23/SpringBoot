package com.Sbe.repository;

import org.springframework.data.repository.CrudRepository;

import com.Sbe.beans.PaymentMethod;



public interface PaymentMethodRepository extends CrudRepository<PaymentMethod,String>{

	

}
