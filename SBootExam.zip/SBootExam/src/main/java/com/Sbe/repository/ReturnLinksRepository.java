package com.Sbe.repository;

import org.springframework.data.repository.CrudRepository;

import com.Sbe.beans.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,Integer>{

}
